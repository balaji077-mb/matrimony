import React from 'react';
import { Text, View } from 'react-native';

function FamilyDetails() {
    return (
      <View>
        <Text> textInComponent </Text>
      </View>
    )
  }


export default FamilyDetails;
