import React from 'react';
import { Text, View } from 'react-native';

function UserInterest() {
    return (
      <View>
        <Text> textInComponent </Text>
      </View>
    )
  }


export default UserInterest;
