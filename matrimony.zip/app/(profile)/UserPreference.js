import React from 'react';
import { Text, View } from 'react-native';

function UserPreference() {
    return (
      <View>
        <Text> textInComponent </Text>
      </View>
    )
  }


export default UserPreference;
