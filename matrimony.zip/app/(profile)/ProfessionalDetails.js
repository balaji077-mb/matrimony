import React from 'react';
import { Text, View } from 'react-native';

function ProfessionalDetails() {
    return (
      <View>
        <Text> textInComponent </Text>
      </View>
    )
  }


export default ProfessionalDetails;
